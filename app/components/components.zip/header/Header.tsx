import { useStore } from '@nanostores/react';
import { ClientOnly } from 'remix-utils/client-only';
import { chatStore } from '~/lib/stores/chat';
import { classNames } from '~/utils/classNames';
import { toggleSidebar } from '~/lib/stores/sidebarStore';
import { ModelSelector } from './ModelSelector';
import { PanelHeaderButton } from '~/components/ui/PanelHeaderButton';
import { useState, useEffect } from 'react';
import { settingsActions } from '~/lib/stores/settings';
import { SettingsPanel } from '~/components/settings/SettingsPanel';

interface HeaderProps {
  model: string;
  setModel: (model: string) => void;
  provider: string;
  setProvider: (provider: string) => void;
  modelList: typeof import('~/utils/constants').MODEL_LIST;
  chatStarted: boolean;
}

export function Header({ model, setModel, provider, setProvider, modelList, chatStarted }: HeaderProps) {
  const chat = useStore(chatStore);
  const providerList = [...new Set(modelList.map((model) => model.provider))];

  return (
    <header className="flex items-center justify-between bg-white border-b border-gray-200 px-4 py-2 shadow-sm">
      <div className="flex items-center gap-4">
        <button
          onClick={() => toggleSidebar()}
          aria-label="Toggle Sidebar"
          className="p-2 rounded-md hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
        >
          <div className="i-ph:sidebar-simple-duotone text-xl text-gray-700" />
        </button>
        <h1 className="text-xl font-bold text-gray-900 select-none">BuildXtreme AI</h1>
      </div>

      <div className="flex items-center gap-2">
        <ModelSelector
          model={model}
          setModel={setModel}
          provider={provider}
          setProvider={setProvider}
          modelList={modelList}
          providerList={providerList}
        />
        <ClientOnly>
          {() => <HeaderButtons chatStarted={chatStarted} />}
        </ClientOnly>
      </div>
      <SettingsPanel />
    </header>
  );
}

function HeaderButtons({ chatStarted }: { chatStarted: boolean }) {
  const [isSyncing, setIsSyncing] = useState(false);
  const [showWorkbench, setShowWorkbench] = useState(false);

  useEffect(() => {
    const initWorkbench = async () => {
      const { workbenchStore } = await import('~/lib/stores/workbench');
      setShowWorkbench(workbenchStore.showWorkbench.get());
      workbenchStore.showWorkbench.listen((value) => setShowWorkbench(value));
    };
    initWorkbench();
  }, []);

  const handleToggleWorkbench = async () => {
    const { workbenchStore } = await import('~/lib/stores/workbench');
    const newShowWorkbench = !showWorkbench;
    workbenchStore.showWorkbench.set(newShowWorkbench);
    setShowWorkbench(newShowWorkbench);
  };

  const handleToggleTerminal = async () => {
    const { workbenchStore } = await import('~/lib/stores/workbench');
    workbenchStore.toggleTerminal(!workbenchStore.showTerminal.get());
  };

  return (
    <>
      <PanelHeaderButton 
        className="text-sm" 
        onClick={handleToggleWorkbench}
        disabled={!chatStarted}
      >
        <div className="i-ph:code" />
        Toggle Code Editor
      </PanelHeaderButton>
      <PanelHeaderButton className="text-sm" onClick={handleToggleTerminal}>
        <div className="i-ph:terminal" />
        Toggle Terminal
      </PanelHeaderButton>
      <PanelHeaderButton 
        className="text-sm" 
        onClick={settingsActions.togglePanel}
        aria-label="Settings"
      >
        <div className="i-ph:gear" />
      </PanelHeaderButton>
    </>
  );
}
