import { LanguageDescription, type LanguageSupport } from '@codemirror/language';
import { createScopedLogger } from '~/utils/logger';

const logger = createScopedLogger('Languages');

interface LanguageModule {
  javascript?: (config?: { jsx?: boolean; typescript?: boolean }) => LanguageSupport;
  html?: () => LanguageSupport;
  css?: () => LanguageSupport;
  sass?: (config?: { indented?: boolean }) => LanguageSupport;
  json?: () => LanguageSupport;
  markdown?: () => LanguageSupport;
  wast?: () => LanguageSupport;
  python?: () => LanguageSupport;
  cpp?: () => LanguageSupport;
}

// Helper function to safely load a language module
async function loadLanguageModule<T extends LanguageModule>(
  importFn: () => Promise<T>,
  errorMessage: string
): Promise<T> {
  if (typeof window === 'undefined') {
    throw new Error('Cannot load language module during SSR');
  }
  
  try {
    const module = await importFn();
    if (!module) {
      throw new Error('Module loaded but returned no content');
    }
    return module;
  } catch (error) {
    logger.error(errorMessage, error);
    throw error;
  }
}

export const supportedLanguages: LanguageDescription[] = [
  LanguageDescription.of({
    name: 'TS',
    extensions: ['ts'],
    async load() {
      const module = await loadLanguageModule(
        () => import('@codemirror/lang-javascript'),
        'Failed to load TypeScript language support'
      );
      return module.javascript({ typescript: true });
    },
  }),
  LanguageDescription.of({
    name: 'JS',
    extensions: ['js', 'mjs', 'cjs'],
    async load() {
      const module = await loadLanguageModule(
        () => import('@codemirror/lang-javascript'),
        'Failed to load JavaScript language support'
      );
      return module.javascript();
    },
  }),
  LanguageDescription.of({
    name: 'TSX',
    extensions: ['tsx'],
    async load() {
      const module = await loadLanguageModule(
        () => import('@codemirror/lang-javascript'),
        'Failed to load TSX language support'
      );
      return module.javascript({ jsx: true, typescript: true });
    },
  }),
  LanguageDescription.of({
    name: 'JSX',
    extensions: ['jsx'],
    async load() {
      const module = await loadLanguageModule(
        () => import('@codemirror/lang-javascript'),
        'Failed to load JSX language support'
      );
      return module.javascript({ jsx: true });
    },
  }),
  LanguageDescription.of({
    name: 'HTML',
    extensions: ['html'],
    async load() {
      const module = await loadLanguageModule(
        () => import('@codemirror/lang-html'),
        'Failed to load HTML language support'
      );
      return module.html();
    },
  }),
  LanguageDescription.of({
    name: 'CSS',
    extensions: ['css'],
    async load() {
      const module = await loadLanguageModule(
        () => import('@codemirror/lang-css'),
        'Failed to load CSS language support'
      );
      return module.css();
    },
  }),
  LanguageDescription.of({
    name: 'SASS',
    extensions: ['sass'],
    async load() {
      const module = await loadLanguageModule(
        () => import('@codemirror/lang-sass'),
        'Failed to load SASS language support'
      );
      return module.sass({ indented: true });
    },
  }),
  LanguageDescription.of({
    name: 'SCSS',
    extensions: ['scss'],
    async load() {
      const module = await loadLanguageModule(
        () => import('@codemirror/lang-sass'),
        'Failed to load SCSS language support'
      );
      return module.sass({ indented: false });
    },
  }),
  LanguageDescription.of({
    name: 'JSON',
    extensions: ['json'],
    async load() {
      const module = await loadLanguageModule(
        () => import('@codemirror/lang-json'),
        'Failed to load JSON language support'
      );
      return module.json();
    },
  }),
  LanguageDescription.of({
    name: 'Markdown',
    extensions: ['md'],
    async load() {
      const module = await loadLanguageModule(
        () => import('@codemirror/lang-markdown'),
        'Failed to load Markdown language support'
      );
      return module.markdown();
    },
  }),
  LanguageDescription.of({
    name: 'Wasm',
    extensions: ['wat'],
    async load() {
      const module = await loadLanguageModule(
        () => import('@codemirror/lang-wast'),
        'Failed to load WebAssembly language support'
      );
      return module.wast();
    },
  }),
  LanguageDescription.of({
    name: 'Python',
    extensions: ['py'],
    async load() {
      const module = await loadLanguageModule(
        () => import('@codemirror/lang-python'),
        'Failed to load Python language support'
      );
      return module.python();
    },
  }),
  LanguageDescription.of({
    name: 'C++',
    extensions: ['cpp'],
    async load() {
      const module = await loadLanguageModule(
        () => import('@codemirror/lang-cpp'),
        'Failed to load C++ language support'
      );
      return module.cpp();
    },
  }),
];

/**
 * Gets the language support for a given file name.
 * Returns undefined if the file type is not supported or if running during SSR.
 */
export async function getLanguage(fileName: string): Promise<LanguageSupport | undefined> {
  if (typeof window === 'undefined') return undefined;

  try {
    const languageDescription = LanguageDescription.matchFilename(supportedLanguages, fileName);
    if (!languageDescription) {
      // Not an error, just no supported language for this file
      return undefined;
    }
    return await languageDescription.load();
  } catch (error) {
    logger.error(`Error loading language support for ${fileName}:`, error);
    return undefined;
  }
}
