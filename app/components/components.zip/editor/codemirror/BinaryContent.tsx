import { memo } from 'react';
import { renderLogger } from '~/utils/logger';

interface BinaryContentProps {
  className?: string;
  message?: string;
}

export const BinaryContent = memo(function BinaryContent({
  className = '',
  message = 'File format cannot be displayed.'
}: BinaryContentProps) {
  renderLogger.trace('BinaryContent');

  return (
    <div 
      className={`flex items-center justify-center absolute inset-0 z-10 text-sm bg-tk-elements-app-backgroundColor text-tk-elements-app-textColor ${className}`}
      role="alert"
      aria-live="polite"
    >
      {message}
    </div>
  );
});
